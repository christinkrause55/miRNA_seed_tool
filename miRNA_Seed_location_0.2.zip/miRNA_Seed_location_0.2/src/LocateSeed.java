/**
 * Class to find a seed sequence of miRNA in a target mRNA object
 * @author christin
 * @version 0.2
 *
 */
public class LocateSeed{
	/**
	 * 7mer-m8: A perfect WC match from nucleotides 2-8 of the miRNA seed.
	 * @param miRNA
	 * @param target
	 * @return
	 */
	public static boolean is7mer_m8(MIRNA miRNA, MRNA target) {
		boolean flag = false;
		
		for(int i = 0; i < target.getLength()-miRNA.getLength(); i++) {
			
			String temp1 = target.getSeq().substring(i,i+miRNA.getLength()-1);
			String temp2 = miRNA.getSeq().substring(1);
			
			if(temp1.equals(temp2)) {		
				flag = true;
				System.out.println(temp1 + " at position "+i);
			}

		}
		return flag;
	}
	
	/**
	 * 7mer-A1: A perfect WC match from nucleotides 2-7 of the miRNA seed in addition 
	 * to an A across from the miRNA nucleotide 1.
	 * @param miRNA
	 * @param target
	 * @return
	 */
	public static boolean is7mer_A1(MIRNA miRNA, MRNA target) {
		boolean flag = false;
		
		for(int i = 1; i < target.getLength()-miRNA.getLength(); i++) {
			
			String temp1 = target.getSeq().substring(i,i+miRNA.getLength()-2);
			String temp2 = miRNA.getSeq().substring(1,miRNA.getLength()-1);
			
		
			if(temp1.equals(temp2)) {		
				if(target.getSeq().charAt(i-1) == 'A') {
					flag = true;
					System.out.println(temp1 + " at position "+i);
				}
			}

		}
		return flag;
	}
	
	/**
	 * 8mer: A perfect WC match from nucleotides 2-8 of the miRNA seed in addition to an A across from the miRNA nucleotide 1.
	 * @param miRNA
	 * @param target
	 * @return boolean if sequence contains 8mer
	 */
	public static boolean is8mer(MIRNA miRNA, MRNA target) {
		boolean flag = false;
		for(int i = 1; i < target.getLength()-miRNA.getLength(); i++) {
			
			String temp1 = target.getSeq().substring(i,i+miRNA.getLength()-1);
			String temp2 = miRNA.getSeq().substring(1);
			
			if(temp1.equals(temp2)) {
				if(target.getSeq().charAt(i-1) == 'A') {
					System.out.println(temp1 + " at position "+i);
					flag = true;
				}
			} 
		}
		return flag;
	}
	
	/**
	 * 6mer: A perfect WC match between the miRNA seed and mRNA for six nucleotides.
	 * @param miRNA
	 * @param target
	 * @return boolean if sequence contains 6mer
	 */
	public static boolean is6mer(MIRNA miRNA, MRNA target) {
		boolean flag = false;
		
		for(int i = 0; i < target.getLength()-miRNA.getLength()+3; i++) {
			
			String temp1 = target.getSeq().substring(i,i+miRNA.getLength()-2);
			
			for(int j=0; j < 3; j++) {
				String temp2 = miRNA.getSeq().substring(j,j+6);
				if(temp1.equals(temp2)) {
					
					if (flag == false){
						System.out.println(temp1 + " at position "+i);
						flag = true;
					}
				} 
			}
		}
		return flag;
	}

	/**
	 * Main method to start the programm
	 * @param args
	 */
	public static void main (String[] args){
		
		MIRNA miRNA = new MIRNA("UUUGGCAAUGGUAGAACUCACACU",2);
		MRNA target = new MRNA("AGATCTGTCTGGCTTTATCACCAGGATGTCACATGTCAGAGAGTATCATTAAAAGAAGACGCTCAGCACTGTTTCAGCCCGAAGCTGCTTGCAGTTTTCTTTTGGATCTGAGCAATGACTGTGTTTGGAAACATCTGTGGACTCTGTTAGATGAGGCACCAACAAGGCAAGGTCACCTGCCTCTTTCCCTTGTTCCCGGATGGGGCATTCATCATTGTGCTGTTTGCGTTTTGTTTTGTTTTGTTTTAACAAAATTAGCTGAAGAAGTTATTCTCAAGAAAATTGGATGTTTTCATTGGCCTTCTTAAATTGTGGCCAGTGTCTTTTAATTTCTTCTTCTTTTCCTTTTGGCAAAGCAGATATAACCCTCAGCATGCTAGGAGAGTGCACCCGTACCTATGGAAGTGGTAAAATCTGGTATTTACTGGCTTACACTCAAAACGACCACAGTCCTACCTCAGTTCAAGGTAAAGCCGGATTTCCGTGGCGGGGGTCCCACAGGACCTCCTGTAGTAGCCCCTGCGCTGTGTGTCTGGAGCGCGGTCCTCGGCCTTATTGAAATGGTCCAAGTAGACAGCTGCTTGTTGGATTCCAGTGCAGGTACCTGCGATGTTTACGTCCACACCGAGCCCAGTGTGGGACTGACATTTCTCAATGGAAGTGAAATTTGGGATTGGACTTTGAAGACGGATTACTAAATAATAATTATTATATGTAACTGAAGCAACCTACTTTTGAAAATCAACTGTATTGGGTAGTGGGAGGTGGGAGGGAAGGGCTTTGGGAAGGGGATGAATATCTCTTTTTACCTTTAACAGACTTGTTTAATCTTCTCGATGTAGATGTTTATGTAGGTACTTCACATTGCAAACGCCTTTTATTCTATTTACAAGCTCAGATGTCTCTGCTCTCCTGAATCTTGGGCATGCCTTTCTGTAACCAAAAATCCCTGTAGGCGTGCTAGCAATTCCAGGGTGGTCCGGGTTTGGCAGATTTGATTTTTAAAAAACGTATTATCTTTAATAAAATGTTATTATGTCAACCAGTGAGGCTGCCCTGAACAAAAAAAACAAAAAGAAAAAAAAAAAAGGAAAGAAAGAAACTGATAAAAAGAGGCATTCCAGCCCCTATGTTATTGATGGAAAAAGAAAAAGAAGAAAAGCAATCTCGCAGTACATGTTACTTGTCGAAAAAATTCCGGACAAGACTACCCTTGTTTTATGTTTTCAGTATTCTGAAAATACCAGTGTGTGGCAGTTCTCGCAGATGTTACCTAAAACTGCTGAACTTGACCGGCAGAATGTTCTGCCGTTTTCTGCTCCCTCGACACTTGATTGGAGGGCTGTCGACCTCTCCTCCCGTGGGGGCTTCCCCAGTGCCTATCTTCTCTGATAGTCATGGAGAGGTTACACTAATTCATTGGAGATGTAAGTTGTTGGTTTTGTTTTGTTTTGTTTTTAGAAAAATATATATAAATATATAATAGATATCTATCGCTATAGAATAATGCATTAATAAAATGAGGCTTTTTTAGAGGAAGACCAAAAAATTCAATGTCTTAAAAATATATTTAATGGCAATGCAAAAGTCTTCCTGCTTCCGTGCTGAACTTTAGAACAGAGGATTGTATTGCAAGACAAAGTTGAATGTAAAGTGATCTCCCTGAACATTTTTAAGGTTTTACTTTTCTGAAATTATACATCACAGCAGTGCATAGGCCATATAATGTTAGCTGGAAGGTCAATTTCAGTGTATGATATACTTTATTAAGATGTATAAAAATCCTGAAGTTTTTATTTAGTTTTGGGAATAGGCATCAATGGGTGGTATTTGCTTTGTAACTCCCCCCAGGTACGATAGGGACTGAATATGGACCCTGCTGAAAGCAGTGTATTGACGCATATTTAACTCGCCCTCTATCCGTAGAGTAGTCATGACACTATACAGATGGTTCGTGTTCATACTGCAGCTTAAAACAAGCAAAATACACAGATGATAATATGCTAAATTTTCCTCTATCCTGTACATTTCACAAAAAGGCATATGCAATATTTACATTTTTAATTTAGTTTACAGAATGGAACCAAAATGTATAAATGTTATGTTTGCTAAAACTTCACAATGTATATTGGGTCTTTGTACATTTTGCCTGACTTACCTTAAATTTAAAATATTTTTTGCTATATAAACTTTAACAGTTATTAAACAGTGTTTTCTTTTTGGGTACGTATTGTTTCTGGATATCAAGATGTTAAATATATTTCTTGCTATTGTGATATGACAAGAGACTTAACTTATCTTGCTCTGTCTTCCACTGTACACGCTGTATATAGGGGTCAATGTGATGCTGCTGGAGACGAGAATAAACTGGACTAGAATAGTGCATTGTATTTAGTCTGTATTGATCATGGATGCCCTCCTTAATAGCCATATGCAATAAAATAAAGTACATTATTTATGAAATGAA");
	
		System.out.println("Seed Sequence of miRNA: " + miRNA.getSeq());	
		
		System.out.println("- - - - - - - - - - - - - - -");
		System.out.println("mRNA contains 8mer: " + is8mer(miRNA, target));
		System.out.println("- - - - - - - - - - - - - - -");
		System.out.println("mRNA contains 6mer: " + is6mer(miRNA, target));
		System.out.println("- - - - - - - - - - - - - - -");
		System.out.println("mRNA contains 7mer_m8: " + is7mer_m8(miRNA, target));
		System.out.println("- - - - - - - - - - - - - - -");
		System.out.println("mRNA contains 7mer_A1: " + is7mer_A1(miRNA, target));
		
	}

}
