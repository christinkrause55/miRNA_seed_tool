/**
* Class to generate a miRNA Object containing a miRNA core
* @author christin
*/
public class MIRNA{


	private int length;
	private String sequence;
	
	/**
	 * Constructor of miRNA core
	 * @param seq String containing core miRNA
	 */
	public MIRNA(String seq){
		this.sequence = seq;
		this.length = this.setLength();
	}
	
	public String getSeq(){
		return this.sequence;
	}
	
	public int getLength(){
		return this.length;
	}

	public int setLength(){

		if(this.sequence.equals("")){
			this.length = 0;
			return 0;
		}

		this.length = this.sequence.length();
		return this.length;
	}
}
